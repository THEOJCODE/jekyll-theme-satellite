---
title: "An Open Letter Against Homeopathy - From An Endometriosis Sufferer"
date: "2025-12-29"
---

# Welcome
Not-so-controversial take, homeopathy should be banned already.

Let me begin properly. I have endometriosis. For the younger members of this sub who might not know, it is essentially a condition where the cells of the inner lining of the uterus - as in, the ones that come out during periods, grow outside the uterus as well. Leading to extreme pain, very heavy flow and in more extreme cases the risk of stones and benign tumors that might need surgical removal. Mine isn't that severe thankfully, or homeopathy would have rlly f-cked me over.

Some more context - my periods have been the bane of my existence since I was a literal child. It caused me to have periods quite early (shortly after my 10th birthday). And several of my core childhood memories involve fainting in the middle of the class in 6th standard because I was constantly in pain during my period. In fact, it was one of these fainting episodes that made my dad force my mom into finally taking me to a real doctor, albeit a terrible one who couldn't diagnose me, and get my first painkiller prescription.  

But before that it was kind of a disaster. During the first two years of my period (approx the end of 4th standard to the end of the 6th), I went through several consultations with my mother's homeopathic doctor. At first, he told me that I had 'hyper-acidity' and something called 'pitta', and advised me that eating cold, chilled foods more often would cure me.

And at first I didn't protest bcs what kid doesn't love having ice-cream and iced water every other day?

Then the colds started. The endometriosis already made me prone to having fevers and headaches while I was on my period. But then I had colds all the time too after listening to that quack, followed by head colds and sinus pains, and had to miss school for it and it basically gave me so much backlog in my first year of middle school. It also contributed to the fainting spells. During my earlier periods I had a lot of trouble keeping food down. Instead I supplemented by pretty much living on iced drinks and those homeopathic sugar pills bcs at the time I was a child and I believed that doctor and I thought that cold foods would cure me.

Ofc they did not. And it only took nearly a year fainting constantly and my dad losing it to finally get my mom to buy a box of real painkillers that made me somewhat functional again.

And it was fine.

For a while.

If you know anything about quacks you'll know that they're really good at brainwashing and finding victims. And that one of the major category of people they like to prey on is privileged and worried young mothers. My mom fell in that category, and over the years she got really close to this one particular homeopath who was one of the oldest practitioners in our city and had the 'friendly old grandpa' persona down to a T. She basically treated him like a therapist. She told him everything and called him for everything, to the point where he visited our home a few times and his grandson became friends with my brother. 

And I was the victim.

At about the age of 13, a year after I started the first painkiller, my endometriosis somehow grew with me and I became resistant to painkillers and I was in pain even more. I experienced dizziness and memory loss and pain and fainting during a swimming practise because of PMS and knew that I needed help, and fast. I asked my mom begged to her, to take me to a gynec or atleast anyone other than that homeopath and she refused. She told me that it was my fault for not being diligent with my medicine and to be more careful. And that painkillers were evil and I should stop taking anything for the pain. It seemed like she cared about that stupid quack more than me if I'm being honest.

And I suffered nearly till adulthood for that. I got severe acne as well due to the period issues. As well as large, painful vaginal boils and cysts that made it had to even walk long distances let alone be active in sports or anything like I used to. I started throwing away my homeopathy sugar pills. And then bcs my mom wouldn't let me switch to a new painkiller I just took multiple pieces of the first one that barely worked anymore. Like, three or four pills at once which was just below overdose category. 

The I turned 16. I took science and studied to become a real doctor bcs like all Indian parents, my mom wanted me to be an mbbs doctor despite being firmly anti-modern medicine. And a few months into my term, I had another fainting episode after years of careful control during my chemistry practical exam. I was so embarassed and it was the most pain I'd been in since forever. And at this point I was used to pain, I was used to leaving school early for a week every month for the pain and I was used to lying in bed for ten hours doing nothing because of pain, but it still hurt so much that day when I fainted.

The only good outcome of that incident was that I finally told my mom that I couldn't take it anymore. I told her that I was worried that something like this might hapoen during board exams or neet and affect my performance there unless she let me upgrade painkillers or see another doctor.

And like a good Indian mom, she told me to shut up and visit that homeopath again.

And it was what he told me then that I finally lost it. He told me, "Run a lap around the yard." because to him the only thing wrong with me was that I was lazy and borderline overweight and I wanted to scream because like, 

"I used to be a swimmer before you people refused to cure my pain and forced me to quit! I didn't quit exercise because I wanted to, I quit it because I physically couldn't move well anymore!"

Somehow I still got through exams though. And after the 12th grade I left NEET and mbbs behind bcs no offense to real doctors, especially the one who finally gave me a diagnosis, but that homeopathic quack soured my impression of the medical field in this country entirely and left me with ptsd. I'm studying humanities now and have a new painkiller and doctor after finally moving out and I've never been happier.
